export const environment = {
  production: true,  
  URL: "https://shock-app-backend-production-eeeb.up.railway.app"
};
