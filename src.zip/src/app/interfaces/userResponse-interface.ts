export interface UserInterface {
    avatar: string,
    id: number,
    name: string
}
