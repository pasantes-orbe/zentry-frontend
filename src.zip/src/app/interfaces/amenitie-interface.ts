export interface AmenitieInterface {
    id:         number;
    name:       string;
    image:      string;
    address:    string;
    id_country: number;
}
