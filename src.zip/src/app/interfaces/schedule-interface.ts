export interface ScheduleInterface {
   day: string
   start: Date
   exit: Date
}
