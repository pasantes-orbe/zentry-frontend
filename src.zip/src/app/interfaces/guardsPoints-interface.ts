export interface GuardPointInterface{
    id_country: string
    id_user: string,
    lat: number,
    lng: number,
    user_lastname: string,
    user_name: string
}