export interface PropertyInterface {
     id: number
     name: string
     number: number
     address: string
     avatar: string
     idCountry: number
}