export interface relationOwnerWithProperty {
    id_user:     number;
    id_property: number;
}
