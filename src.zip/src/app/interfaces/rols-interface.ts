export interface Rols {
  id: number;
  name: string;
  avatar: any;
}
