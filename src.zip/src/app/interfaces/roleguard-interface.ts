export interface RoleGuard {
    roleType: string;
}