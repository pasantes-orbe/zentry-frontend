import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-politica-de-privacidad',
  templateUrl: './politica-de-privacidad.page.html',
  styleUrls: ['./politica-de-privacidad.page.scss'],
})
export class PoliticaDePrivacidadPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
