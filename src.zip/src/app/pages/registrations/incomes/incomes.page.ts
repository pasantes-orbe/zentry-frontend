import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-incomes-page',
  templateUrl: './incomes.page.html',
  styleUrls: ['./incomes.page.scss'],
})
export class IncomesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
