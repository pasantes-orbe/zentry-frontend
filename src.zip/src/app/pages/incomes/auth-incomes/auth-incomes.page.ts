import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auth-incomes',
  templateUrl: './auth-incomes.page.html',
  styleUrls: ['./auth-incomes.page.scss'],
})
export class AuthIncomesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
